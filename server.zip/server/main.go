package main

import (
	"fmt"
	"net/http"
	"time"

	"server/controller"
	"server/models"

	"github.com/gorilla/mux"
	log "github.com/sirupsen/logrus"
)

func RemoveIndex(s []models.CmdJson, index int) []models.CmdJson {
	return append(s[:index], s[index+1:]...)
}

/*
a := []int{}
a = append(a, 3, 4) // a == [3 4]
*/
func sendCommand() {
	for {
		time.Sleep(3 * time.Second)
		// komanda bo'lsa bajarish uzatish
		if len(controller.Cmds) > 0 {

			controller.MTX.Lock()
			cc := controller.Cmds[0]
			fmt.Println("Has new command:", cc)
			if len(controller.Cmds) == 1 {
				var _cmd []models.CmdJson
				controller.Cmds = _cmd
			} else if len(controller.Cmds) > 1 {
				controller.Cmds = RemoveIndex(controller.Cmds, 0)
			}
			controller.MTX.Unlock()

			// send command
			fmt.Println("Start sending comand...")
			fmt.Println(models.CmdToCamera(&cc))
			// wait 5s for viewing
			fmt.Println("waiting 5s for viewering operator")
			//time.Sleep(5 * time.Second)
		}
	}
}

func main() {

	router := mux.NewRouter().StrictSlash(true)
	router = router.PathPrefix("/api/").Subrouter()

	// credentila olib profile va status qaytaradi
	router.HandleFunc("/check", controller.CameraCheck).Methods("POST")
	router.HandleFunc("/status", controller.CameraPTZStatus).Methods("POST")
	router.HandleFunc("/cmd", controller.CameraCmd).Methods("POST")

	go func() {
		sendCommand()
	}()

	log.Fatal(http.ListenAndServe("127.0.0.1:7777", router))
	log.Exit(0)
}
