package models

import (
	"encoding/xml"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"reflect"
	"strings"

	"github.com/beevik/etree"
	goonvif "github.com/use-go/onvif"
	"github.com/use-go/onvif/device"
	"github.com/use-go/onvif/gosoap"
	"github.com/use-go/onvif/media"
	"github.com/use-go/onvif/ptz"
	"github.com/use-go/onvif/xsd"
	"github.com/use-go/onvif/xsd/onvif"

	dac "github.com/xinsnake/go-http-digest-auth-client"
)

type CheckJson struct {
	Ip    string `json:"ip"`
	Port  string `json:"port"`
	Login string `json:"login"`
	Parol string `json:"parol"`
}

type PTZLocationJson struct {
	Ip           string `json:"ip"`
	Port         string `json:"port"`
	Login        string `json:"login"`
	Parol        string `json:"parol"`
	ProfileToken string `json:"profile_token"`
}

type CmdJson struct {
	Ip           string  `json:"ip"`
	Port         string  `json:"port"`
	Login        string  `json:"login"`
	Parol        string  `json:"parol"`
	ProfileToken string  `json:"profile_token"`
	X            float32 `json:"x"`
	Y            float32 `json:"y"`
	Z            float32 `json:"z"`
}

// Xlmns XML Scheam
var Xlmns = map[string]string{
	"onvif":   "http://www.onvif.org/ver10/schema",
	"tds":     "http://www.onvif.org/ver10/device/wsdl",
	"trt":     "http://www.onvif.org/ver10/media/wsdl",
	"tev":     "http://www.onvif.org/ver10/events/wsdl",
	"tptz":    "http://www.onvif.org/ver20/ptz/wsdl",
	"timg":    "http://www.onvif.org/ver20/imaging/wsdl",
	"tan":     "http://www.onvif.org/ver20/analytics/wsdl",
	"xmime":   "http://www.w3.org/2005/05/xmlmime",
	"wsnt":    "http://docs.oasis-open.org/wsn/b-2",
	"xop":     "http://www.w3.org/2004/08/xop/include",
	"wsa":     "http://www.w3.org/2005/08/addressing",
	"wstop":   "http://docs.oasis-open.org/wsn/t-1",
	"wsntw":   "http://docs.oasis-open.org/wsn/bw-2",
	"wsrf-rw": "http://docs.oasis-open.org/wsrf/rw-2",
	"wsaw":    "http://www.w3.org/2006/05/addressing/wsdl",
}

func readResponse(resp *http.Response) string {
	b, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		panic(err)
	}
	return string(b)
}

func getProfileToken(resp string) string {
	ret := ""
	type ProfileResponse struct {
		XMLName  xml.Name
		Profiles []onvif.Profile
	}
	type Body struct {
		XMLName             xml.Name
		GetProfilesResponse ProfileResponse //`xml:"GetProfilesResponse"`
	}
	type MyGetProfiles struct {
		XMLName xml.Name
		Body    Body
	}

	profiles := &MyGetProfiles{}
	err := xml.Unmarshal([]byte(resp), profiles)
	if err != nil {
		fmt.Println("Error:", err)
	} else {
		fmt.Println("Success")
		fmt.Println()
		l := len(profiles.Body.GetProfilesResponse.Profiles)
		for i := 0; i < l; i++ {
			p := profiles.Body.GetProfilesResponse.Profiles[i]
			ret = string(p.Token)
			break
		}
	}
	return ret
}

func getCurrentPosition(resp string) (float32, float32, float32) {
	var X float32 = 10.0
	var Y float32 = 10.0
	var Z float32 = 10.0

	type MoveStatus struct {
		Status string
	}

	type PTZMoveStatus struct {
		PanTilt MoveStatus
		Zoom    MoveStatus
	}

	type Vector2D struct {
		X     float64    `xml:"x,attr"`
		Y     float64    `xml:"y,attr"`
		Space xsd.AnyURI `xml:"space,attr"`
	}

	type Vector1D struct {
		X     float64    `xml:"x,attr"`
		Space xsd.AnyURI `xml:"space,attr"`
	}

	type PTZVector struct {
		PanTilt Vector2D //`xml:"onvif:PanTilt"`
		Zoom    Vector1D //`xml:"onvif:Zoom"`
	}

	type PTZStatus struct {
		XMLName    xml.Name
		Position   PTZVector
		MoveStatus PTZMoveStatus
		Error      string
		UtcTime    xsd.DateTime
	}

	// parse X Y Z coordinates
	type StatusResponse struct {
		XMLName   xml.Name
		PTZStatus []PTZStatus
	}
	type Body struct {
		XMLName           xml.Name
		GetStatusResponse StatusResponse `xml:"GetStatusResponse"`
	}
	type MyGetProfiles struct {
		XMLName xml.Name
		Body    Body
	}

	statuses := &MyGetProfiles{}
	err := xml.Unmarshal([]byte(resp), statuses)
	if err != nil {
		fmt.Println("Error:", err)
	} else {
		//fmt.Println(statuses.Body.XMLName)
		//fmt.Println(statuses.Body.GetStatusResponse.XMLName)
		if len(statuses.Body.GetStatusResponse.PTZStatus) > 0 {
			//fmt.Println(statuses.Body.GetStatusResponse.PTZStatus[0].Position.PanTilt)
			//fmt.Println(statuses.Body.GetStatusResponse.PTZStatus[0].Position.Zoom)
			X = float32(statuses.Body.GetStatusResponse.PTZStatus[0].Position.PanTilt.X)
			Y = float32(statuses.Body.GetStatusResponse.PTZStatus[0].Position.PanTilt.Y)
			Z = float32(statuses.Body.GetStatusResponse.PTZStatus[0].Position.Zoom.X)
		}

	}

	return X, Y, Z
}

func CheckCamera(cj *CheckJson) map[string]interface{} {

	ret := map[string]interface{}{"status": false, "message": "Ulanishda xatolik!"}
	var body []byte
	var resp3 *http.Response
	// connect to device
	dev, err := goonvif.NewDevice(goonvif.DeviceParams{
		Xaddr:      cj.Ip + ":" + cj.Port,
		Username:   cj.Login,
		Password:   cj.Parol,
		HttpClient: new(http.Client),
	})
	if err != nil {
		fmt.Println("error connection", cj)
		return ret
	}

	// get device capabilities
	getCapabilities := device.GetCapabilities{Category: "All"}
	getCapabilitiesResponse, err := dev.CallMethod(getCapabilities)
	if err != nil {
		log.Println(err)
		return ret
	} else {
		resp := readResponse(getCapabilitiesResponse)
		fmt.Println("getCapabilitiesResponse:")
		fmt.Println(gosoap.SoapMessage(resp).StringIndent())

		subStr1 := "/onvif/ptz_service"
		subStr12 := "/onvif/PTZ"
		subStr2 := "tt:PTZ"
		if (strings.Contains(resp, subStr1) || strings.Contains(resp, subStr12)) && strings.Contains(resp, subStr2) {

			// endi profile token larini olishimiz kerak
			getProfiles := media.GetProfiles{}
			getProfilesResponse, err := dev.CallMethod(getProfiles)
			fmt.Println(getProfiles, err)
			if err != nil {
				return ret
			} else {
				resp2 := readResponse(getProfilesResponse)
				fmt.Println("GetProfileResponse:")
				fmt.Println(gosoap.SoapMessage(resp2).StringIndent())

				token := ""
				// digest ni tekshirib ko'ramiz
				digestCheckStr := "The security token could not be authenticated or authorized"
				checkStr2 := "not authorized"
				if strings.Contains(resp2, digestCheckStr) || strings.Contains(resp2, checkStr2) {
					// digest ni tekshirish
					//
					// ba'zi ma'lumotlarni o'zimiz olishga harakat qilamiz
					fmt.Println("Digest boshlandi")
					pkgPath := strings.Split(reflect.TypeOf(getProfiles).PkgPath(), "/")
					pkg := strings.ToLower(pkgPath[len(pkgPath)-1])
					endpoint_url := dev.GetEndpoint(pkg)
					output, err := xml.MarshalIndent(getProfiles, "  ", "    ")
					if err != nil {
						fmt.Println("Digest err-1")
						return map[string]interface{}{"status": true, "message": "OK", "token": ""}
					}
					outputStr := string(output)

					doc := etree.NewDocument()
					if err := doc.ReadFromString(outputStr); err != nil {
						fmt.Println("Digest err-2")
						return map[string]interface{}{"status": true, "message": "OK", "token": ""}
					}
					element := doc.Root()

					soap := gosoap.NewEmptySOAP()
					soap.AddBodyContent(element)
					soap.AddRootNamespaces(Xlmns)
					soap.AddAction()
					//soap.AddWSSecurity(cj.Login, cj.Parol)
					soapStr := soap.String()

					dr := dac.NewRequest(cj.Login, cj.Parol, "POST", endpoint_url, soapStr)

					if resp3, err = dr.Execute(); err != nil {
						log.Fatalln(err)
					}
					defer resp3.Body.Close()

					if body, err = ioutil.ReadAll(resp3.Body); err != nil {
						log.Fatalln(err)
					}
					fmt.Println("Digest response:")
					fmt.Println(gosoap.SoapMessage(body).StringIndent())
					token = getProfileToken(string(body))
				} else {
					token = getProfileToken(string(resp2))
				}

				fmt.Println("token:", token)
				ret = map[string]interface{}{"status": true, "message": "OK", "token": token}
			}
		} else {
			ret["message"] = "PTZ xizmat topilmadi"
			fmt.Println("Error ptz not found")
			return ret
		}

	}
	// check PTZ has or not
	// get profiles
	// get first profile token

	// return
	// status
	// token
	return ret
}

func PTZLocation(ptzl *PTZLocationJson) map[string]interface{} {
	var body []byte
	var resp3 *http.Response

	ret := map[string]interface{}{"status": false, "message": ""}
	// connect to device
	dev, err := goonvif.NewDevice(goonvif.DeviceParams{
		Xaddr:      ptzl.Ip + ":" + ptzl.Port,
		Username:   ptzl.Login,
		Password:   ptzl.Parol,
		HttpClient: new(http.Client),
	})
	if err != nil {
		log.Println(err)
		return ret
	}
	tk := onvif.ReferenceToken(ptzl.ProfileToken)
	getStatus := ptz.GetStatus{ProfileToken: tk}
	getStatusResponse, err1 := dev.CallMethod(getStatus)
	if err1 != nil {
		log.Println(err1)
	} else {
		resp := readResponse(getStatusResponse)
		fmt.Println("getStatusResponse:")
		fmt.Println(gosoap.SoapMessage(resp).StringIndent())

		digestCheckStr := "The security token could not be authenticated or authorized"
		checkStr2 := "not authorized"
		if strings.Contains(resp, digestCheckStr) || strings.Contains(resp, checkStr2) {
			// zaprosni qurish
			pkgPath := strings.Split(reflect.TypeOf(getStatus).PkgPath(), "/")
			pkg := strings.ToLower(pkgPath[len(pkgPath)-1])
			endpoint_url := dev.GetEndpoint(pkg)
			output, err := xml.MarshalIndent(getStatus, "  ", "    ")
			if err != nil {
				return ret
			}
			outputStr := string(output)
			doc := etree.NewDocument()
			if err := doc.ReadFromString(outputStr); err != nil {
				return ret
			}
			element := doc.Root()

			soap := gosoap.NewEmptySOAP()
			soap.AddBodyContent(element)
			soap.AddRootNamespaces(Xlmns)
			soap.AddAction()
			soapStr := soap.String()
			dr := dac.NewRequest(ptzl.Login, ptzl.Parol, "POST", endpoint_url, soapStr)

			if resp3, err = dr.Execute(); err != nil {
				log.Fatalln(err)
			}
			defer resp3.Body.Close()

			if body, err = ioutil.ReadAll(resp3.Body); err != nil {
				log.Fatalln(err)
			}
			fmt.Println("Digest response:")
			fmt.Println(gosoap.SoapMessage(body).StringIndent())
			X, Y, Z := getCurrentPosition(string(body))

			type PTZCurLoc struct {
				X float32 `json:"x"`
				Y float32 `json:"y"`
				Z float32 `json:"z"`
			}

			ret = map[string]interface{}{"status": true, "message": ""}
			ret["x"] = X
			ret["y"] = Y
			ret["z"] = Z
			fmt.Println("curLoc:", X, Y, Z)
		} else {
			X, Y, Z := getCurrentPosition(resp)

			type PTZCurLoc struct {
				X float32 `json:"x"`
				Y float32 `json:"y"`
				Z float32 `json:"z"`
			}

			ret = map[string]interface{}{"status": true, "message": ""}
			ret["x"] = X
			ret["y"] = Y
			ret["z"] = Z
			fmt.Println("curLoc:", X, Y, Z)
		}
	}
	return ret
}

func CmdToCamera(cc *CmdJson) map[string]interface{} {
	var body []byte
	var resp3 *http.Response
	ret := map[string]interface{}{"status": false, "message": ""}

	// connect to device
	dev, err := goonvif.NewDevice(goonvif.DeviceParams{
		Xaddr:      cc.Ip + ":" + cc.Port,
		Username:   cc.Login,
		Password:   cc.Parol,
		HttpClient: new(http.Client),
	})
	if err != nil {
		log.Println(err)
		return ret
	}
	fmt.Println(cc.X, cc.Y, cc.Z)
	pt := onvif.Vector2D{
		X:     float64(cc.X),
		Y:     float64(cc.Y),
		Space: "http://www.onvif.org/ver10/tptz/PanTiltSpaces/PositionGenericSpace"}

	/*
			type PTZSpeed struct {
		PanTilt Vector2D `xml:"onvif:PanTilt"`
		Zoom    Vector1D `xml:"onvif:Zoom"`
	}*/
	z := onvif.Vector1D{
		X:     float64(cc.Z),
		Space: "http://www.onvif.org/ver10/tptz/ZoomSpaces/PositionGenericSpace"}

	pos := onvif.PTZVector{
		PanTilt: pt,
		Zoom:    z}

	sp1 := onvif.Vector2D{
		X:     0.1,
		Y:     0.1,
		Space: "http://www.onvif.org/ver10/tptz/PanTiltSpaces/GenericSpeedSpace"}
	sp2 := onvif.Vector1D{
		X:     0.1,
		Space: "http://www.onvif.org/ver10/tptz/ZoomSpaces/ZoomGenericSpeedSpace"}

	speed := onvif.PTZSpeed{PanTilt: sp1, Zoom: sp2}
	amv := ptz.AbsoluteMove{
		ProfileToken: onvif.ReferenceToken(cc.ProfileToken),
		Position:     pos,
		Speed:        speed}

	// Relative
	setAbsoluteMoveResp, err2 := dev.CallMethod(amv)
	if err2 != nil {
		log.Println(err2)
	} else {
		resp := readResponse(setAbsoluteMoveResp)
		fmt.Println(gosoap.SoapMessage(resp).StringIndent())
		digestCheckStr := "The security token could not be authenticated or authorized"
		checkStr2 := "not authorized"
		if strings.Contains(resp, digestCheckStr) || strings.Contains(resp, checkStr2) {
			// fmt.Println("digest kk bizga")
			pkgPath := strings.Split(reflect.TypeOf(amv).PkgPath(), "/")
			pkg := strings.ToLower(pkgPath[len(pkgPath)-1])
			endpoint_url := dev.GetEndpoint(pkg)
			output, err := xml.MarshalIndent(amv, "  ", "    ")
			if err != nil {
				return map[string]interface{}{"status": false, "message": "OK"}
			}
			outputStr := string(output)
			doc := etree.NewDocument()
			if err := doc.ReadFromString(outputStr); err != nil {
				return map[string]interface{}{"status": true, "message": "OK"}
			}
			element := doc.Root()

			soap := gosoap.NewEmptySOAP()
			soap.AddBodyContent(element)
			soap.AddRootNamespaces(Xlmns)
			soap.AddAction()
			soapStr := soap.String()

			dr := dac.NewRequest(cc.Login, cc.Parol, "POST", endpoint_url, soapStr)

			if resp3, err = dr.Execute(); err != nil {
				log.Fatalln(err)
			}
			defer resp3.Body.Close()

			if body, err = ioutil.ReadAll(resp3.Body); err != nil {
				log.Fatalln(err)
			}
			fmt.Println("Digest response:")
			fmt.Println(gosoap.SoapMessage(body).StringIndent())
		}

		ret = map[string]interface{}{"status": true, "message": ""}
	}
	return ret
}
