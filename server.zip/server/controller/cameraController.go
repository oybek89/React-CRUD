package controller

import (
	"encoding/json"
	"fmt"
	"net/http"
	"sync"

	"server/models"
)

var Cmds []models.CmdJson
var MTX sync.Mutex

func Message(status bool, message string) map[string]interface{} {
	return map[string]interface{}{"status": status, "message": message}
}

func Respond(w http.ResponseWriter, data map[string]interface{}) {
	w.Header().Add("Content-Type", "application/json")
	json.NewEncoder(w).Encode(data)
}

var CameraCheck = func(w http.ResponseWriter, r *http.Request) {
	fmt.Println("CameraCheck")
	cj := &models.CheckJson{}
	err := json.NewDecoder(r.Body).Decode(cj)
	if err != nil {
		Respond(w, Message(false, "Invalid request JSON"))
		return
	}
	fmt.Println(cj)
	resp := models.CheckCamera(cj)
	Respond(w, resp)
	return
}

var CameraPTZStatus = func(w http.ResponseWriter, r *http.Request) {
	fmt.Println("CameraPTZStatus")
	ptzl := &models.PTZLocationJson{}
	err := json.NewDecoder(r.Body).Decode(ptzl)
	if err != nil {
		Respond(w, Message(false, "Invalid request JSON"))
		return
	}

	resp := models.PTZLocation(ptzl)
	Respond(w, resp)
	return
}

var CameraCmd = func(w http.ResponseWriter, r *http.Request) {
	fmt.Println("CameraCmd")
	cc := &models.CmdJson{}
	err := json.NewDecoder(r.Body).Decode(cc)
	if err != nil {
		Respond(w, Message(false, "Invalid request JSON"))
		return
	}

	if len(cc.Ip) < 5 || len(cc.Port) < 2 || len(cc.Parol) < 3 || len(cc.Login) < 3 || len(cc.ProfileToken) < 5 {

		Respond(w, Message(false, "Xatolik"))

	} else {
		MTX.Lock()
		Cmds = append(Cmds, *cc)
		MTX.Unlock()
		Respond(w, Message(true, "Qo'shildi"))
	}
	return
}
